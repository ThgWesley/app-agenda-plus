// --- ESTADO DA APLICAÇÃO ---
let clientes = JSON.parse(localStorage.getItem('agendaPlus_clientes')) || [];
let appConfig = JSON.parse(localStorage.getItem('agendaPlus_config')) || {
    nome: "Agenda Plus",
    cor: "#6c5ce7",
    fotoPerfil: "https://via.placeholder.com/40"
};

let currentDate = new Date();

// --- INICIALIZAÇÃO ---
window.onload = function() {
    aplicarConfiguracoes();
    renderCalendar();
    atualizarFinancas();
};

// --- NAVEGAÇÃO ---
function navTo(viewName) {
    // Esconder todas as views
    document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
    document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
    
    // Mostrar a view solicitada
    document.getElementById(`view-${viewName}`).classList.add('active');
    document.getElementById(`nav-${viewName}`).classList.add('active');

    // Ações específicas por aba
    if(viewName === 'agenda') renderCalendar();
    if(viewName === 'financas') atualizarFinancas();
}

// --- CALENDÁRIO ---
function changeMonth(direction) {
    currentDate.setMonth(currentDate.getMonth() + direction);
    renderCalendar();
}

function renderCalendar() {
    const grid = document.getElementById('calendar-grid');
    const monthDisplay = document.getElementById('month-year-display');
    const eventsList = document.getElementById('events-list');
    
    grid.innerHTML = '';
    eventsList.innerHTML = '';

    const year = currentDate.getFullYear();
    const month = currentDate.getMonth();
    
    const meses = ["Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho", "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"];
    monthDisplay.innerText = `${meses[month]} ${year}`;

    const daysInMonth = new Date(year, month + 1, 0).getDate();
    const firstDay = new Date(year, month, 1).getDay();

    // Cabeçalho dos dias
    const diasSemana = ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'];
    diasSemana.forEach(dia => {
        let div = document.createElement('div');
        div.className = 'day-name';
        div.innerText = dia;
        grid.appendChild(div);
    });

    // Espaços vazios no início do mês
    for (let i = 0; i < firstDay; i++) {
        let div = document.createElement('div');
        grid.appendChild(div);
    }

    // Dias do mês
    const hoje = new Date();
    
    // Filtra eventos do mês para exibir na lista embaixo do calendário
    let eventosDoMes = clientes.filter(c => {
        let dataC = new Date(c.data + "T00:00:00");
        return dataC.getMonth() === month && dataC.getFullYear() === year;
    });

    // Ordenar eventos por data
    eventosDoMes.sort((a,b) => new Date(a.data) - new Date(b.data));

    for (let day = 1; day <= daysInMonth; day++) {
        let div = document.createElement('div');
        div.className = 'cal-day';
        div.innerText = day;
        
        let stringData = `${year}-${String(month+1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
        
        // Verifica se é hoje
        if (day === hoje.getDate() && month === hoje.getMonth() && year === hoje.getFullYear()) {
            div.classList.add('active');
        }

        // Verifica se tem evento neste dia
        let temEvento = eventosDoMes.some(c => c.data === stringData);
        if(temEvento) {
            div.classList.add('has-event');
        }

        // Ao clicar num dia, vai para registro preenchendo a data
        div.onclick = () => {
            document.getElementById('reg-data').value = stringData;
            navTo('registro');
        };

        grid.appendChild(div);
    }

    // Renderizar lista de eventos
    if(eventosDoMes.length === 0) {
        eventsList.innerHTML = "<p style='color:#999; text-align:center;'>Nenhum evento neste mês.</p>";
    } else {
        eventosDoMes.forEach(ev => {
            let [y, m, d] = ev.data.split('-');
            eventsList.innerHTML += `
                <div class="event-card">
                    <div class="event-details">
                        <h4>${ev.cliente} (${d}/${m})</h4>
                        <p>${ev.kit} - ${ev.categoria}</p>
                    </div>
                    <div class="event-status ${ev.status}">${ev.status}</div>
                </div>
            `;
        });
    }
}

// --- LÓGICA DO REGISTRO ---
function toggleBaloes() {
    const isChecked = document.getElementById('reg-tem-balao').checked;
    document.getElementById('baloes-container').style.display = isChecked ? 'block' : 'none';
}

function salvarCliente(e) {
    e.preventDefault();

    const data = document.getElementById('reg-data').value;
    const cliente = document.getElementById('reg-cliente').value;
    const kit = document.getElementById('reg-kit').value;
    const categoria = document.getElementById('reg-categoria').value;
    const valor = parseFloat(document.getElementById('reg-valor').value);
    const pagamento = document.getElementById('reg-pagamento').value;
    const status = document.getElementById('reg-status').value;
    
    // Balões
    const temBalao = document.getElementById('reg-tem-balao').checked;
    const tamanhoBalao = temBalao ? document.getElementById('reg-tamanho-balao').value : null;
    const coresBalao = temBalao ? document.getElementById('reg-cores-balao').value : null;

    // Processamento da Foto (Convertendo para Base64 para salvar no navegador)
    const fotoInput = document.getElementById('reg-foto');
    let fotoBase64 = null;

    if (fotoInput.files && fotoInput.files[0]) {
        const reader = new FileReader();
        reader.onload = function(event) {
            fotoBase64 = event.target.result;
            finalizarSalvamento();
        };
        reader.readAsDataURL(fotoInput.files[0]);
    } else {
        finalizarSalvamento();
    }

    function finalizarSalvamento() {
        const novoCliente = {
            id: Date.now(),
            data,
            cliente,
            kit,
            categoria,
            temBalao,
            tamanhoBalao,
            coresBalao,
            valor,
            pagamento,
            status,
            fotoKit: fotoBase64
        };

        clientes.push(novoCliente);
        localStorage.setItem('agendaPlus_clientes', JSON.stringify(clientes));

        alert("Cliente registrado com sucesso!");
        document.getElementById('form-registro').reset();
        toggleBaloes(); // Esconde o painel de balões se estiver aberto
        navTo('agenda'); // Volta pra agenda pra ver o evento salvo
    }
}

// --- LÓGICA DE FINANÇAS ---
function atualizarFinancas() {
    let faturamentoTotal = 0;
    
    // Soma o valor de todos os clientes registrados
    clientes.forEach(c => {
        faturamentoTotal += c.valor;
    });

    document.getElementById('fin-total').innerText = `R$ ${faturamentoTotal.toFixed(2).replace('.', ',')}`;
    calcularDivisao(faturamentoTotal);
}

function calcularDivisao(totalParam = null) {
    let totalText = document.getElementById('fin-total').innerText.replace('R$ ', '').replace(',', '.');
    let faturamento = totalParam !== null ? totalParam : parseFloat(totalText) || 0;
    
    let porcentagemVoce = document.getElementById('fin-slider').value;
    document.getElementById('percent-display').innerText = `${porcentagemVoce}%`;

    let valorVoce = faturamento * (porcentagemVoce / 100);
    let valorLoja = faturamento - valorVoce;

    document.getElementById('fin-voce').innerText = `R$ ${valorVoce.toFixed(2).replace('.', ',')}`;
    document.getElementById('fin-loja').innerText = `R$ ${valorLoja.toFixed(2).replace('.', ',')}`;
}

// --- GERAR RELATÓRIO PNG ---
function gerarRelatorioPNG() {
    // 1. Preencher a tabela oculta com os dados
    const tbody = document.getElementById('rel-tbody');
    tbody.innerHTML = '';
    
    let total = 0;

    clientes.forEach(c => {
        let [y, m, d] = c.data.split('-');
        let dataFormatada = `${d}/${m}/${y}`;
        total += c.valor;

        tbody.innerHTML += `
            <tr>
                <td style="padding: 10px; border: 1px solid #ccc;">${dataFormatada}</td>
                <td style="padding: 10px; border: 1px solid #ccc;">${c.cliente}</td>
                <td style="padding: 10px; border: 1px solid #ccc;">${c.kit} (${c.categoria})</td>
                <td style="padding: 10px; border: 1px solid #ccc;">R$ ${c.valor.toFixed(2).replace('.', ',')}</td>
                <td style="padding: 10px; border: 1px solid #ccc;">${c.status}</td>
            </tr>
        `;
    });

    document.getElementById('rel-total').innerText = `Faturamento Total: R$ ${total.toFixed(2).replace('.', ',')}`;
    document.getElementById('rel-title').innerText = `Relatório de Vendas - ${appConfig.nome}`;

    // 2. Tirar print da área oculta usando html2canvas
    const areaPrint = document.getElementById('relatorio-print-area');
    
    html2canvas(areaPrint).then(canvas => {
        // Criar um link para download
        let link = document.createElement('a');
        link.download = `Relatorio_${appConfig.nome.replace(/\s+/g, '')}.png`;
        link.href = canvas.toDataURL("image/png");
        link.click();
    });
}

// --- LÓGICA DE PERFIL E CONFIGURAÇÃO ---
function aplicarConfiguracoes() {
    document.getElementById('header-company-name').innerText = appConfig.nome;
    document.getElementById('config-nome').value = appConfig.nome;
    
    document.getElementById('header-profile-img').src = appConfig.fotoPerfil;
    
    document.getElementById('config-cor').value = appConfig.cor;
    document.documentElement.style.setProperty('--primary-color', appConfig.cor);
}

function salvarNomeApp() {
    appConfig.nome = document.getElementById('config-nome').value || "Agenda Plus";
    salvarConfig();
    alert("Nome atualizado!");
}

function mudarCorApp() {
    appConfig.cor = document.getElementById('config-cor').value;
    salvarConfig();
}

function salvarFotoPerfil(event) {
    const file = event.target.files[0];
    if(file) {
        const reader = new FileReader();
        reader.onload = function(e) {
            appConfig.fotoPerfil = e.target.result;
            salvarConfig();
        };
        reader.readAsDataURL(file);
    }
}

function salvarConfig() {
    localStorage.setItem('agendaPlus_config', JSON.stringify(appConfig));
    aplicarConfiguracoes();
}

// --- BACKUP E RESTAURAÇÃO ---
function exportarDadosJSON() {
    const dataObj = {
        config: appConfig,
        clientes: clientes
    };
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(dataObj));
    const link = document.createElement("a");
    link.setAttribute("href", dataStr);
    link.setAttribute("download", "Backup_AgendaPlus.json");
    link.click();
}

function importarDadosJSON(event) {
    const file = event.target.files[0];
    if(file) {
        const reader = new FileReader();
        reader.onload = function(e) {
            try {
                const importado = JSON.parse(e.target.result);
                if(importado.clientes && importado.config) {
                    clientes = importado.clientes;
                    appConfig = importado.config;
                    localStorage.setItem('agendaPlus_clientes', JSON.stringify(clientes));
                    salvarConfig(); // já chama o localStorage pra config e aplica
                    renderCalendar();
                    atualizarFinancas();
                    alert("Backup restaurado com sucesso!");
                } else {
                    alert("Arquivo de backup inválido.");
                }
            } catch (err) {
                alert("Erro ao ler o arquivo.");
            }
        };
        reader.readAsText(file);
    }
}
